
use ExtUtils::testlib ;

BEGIN { print "loading ... " } ;

use ExtUtils::XSBuilder::WrapXS ;

print "ok\n" ;
