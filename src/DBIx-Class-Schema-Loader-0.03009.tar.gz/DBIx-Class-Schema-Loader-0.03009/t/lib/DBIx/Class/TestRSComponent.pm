package DBIx::Class::TestRSComponent;
use base qw/DBIx::Class::ResultSet/;

sub dbix_class_testrscomponent { 'dbix_class_testrscomponent works' }

1;
