#!/bin/sh

src="$1"
dst="$2"
shift 2

cd "$src"
install -d -m0755 "$dst"

find "$@" | while read fn; do
	if [ -d "$fn" ]; then
		install -d -m0755 "$dst/$fn"
	elif [ -f "$fn" ]; then
		case "$fn" in
		*/*)
			dir=`dirname $fn`
			install -d -m0755 "$dst/$dir"
			;;
		esac
		install -m 0644 "$src/$fn" "$dst/$fn"
	fi
done
