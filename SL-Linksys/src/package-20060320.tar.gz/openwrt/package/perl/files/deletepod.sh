#!/bin/sh

[ "$#" -gt 0 ] || set .
echo "---> Deleting pod docs in: $@" >&2
find "$@" -type f -and -name \*.pod | xargs rm -f
